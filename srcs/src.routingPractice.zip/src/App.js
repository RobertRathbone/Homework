import { useEffect, useState } from 'react';
import { Router } from '@reach/router';
// import axios from 'axios';
import './App.css';
import RouteHome from './components/RouteHome';
import RouteNumber from './components/RouteNumber';
import RouteHello from './components/RouteHello';
import RouteFancyHello from './components/RouteFancyHello';



function App() {

  return (
    <div className="App">
        <Router>
            <RouteHome path="/"/>
            <RouteNumber path="/:id"/>
            <RouteHello path="/hello"/>
            <RouteFancyHello path ="/hello/:color1/:color2"/>
        </Router>
    </div>
  );
}


export default App;

