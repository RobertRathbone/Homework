import {useState} from 'react';

const Box = ({box, index, deleteBox, updateBox}) => {
    return (
           <span
            style={{
                    backgroundColor: 'grey',
                    height: '100px',
                    width: '300px',
                    display: "block",
                    verticalAlign: "top",
                    textDecoration: box.status ? "line-through" : ""
                    }}>
                        Task: {box.task}
                <p>Mark as completed<input
                                        type="checkbox"
                                        checked={box.status}
                                        onChange={e => updateBox(index)}/>
                </p>
                <button onClick={(e) => deleteBox(index)}>Delete</button>
            </span>
    )
}

export default Box;
import react, {useState} from 'react';
import logo from './logo.svg';
import './App.css';
import Boxes from './components/Boxes';
import New from './components/New';

// redux

// function App() {

//   const [boxes, setBoxes] = useState([
//     {task: "rake", status: false},
//     {task: "cook", status: true},
//     {task: "clean", status: false},
//   ])

//   const createBox = (box) => {
//     setBoxes([...boxes, box])
//   };

//   const deleteBox = (deleteIndex) => {
//     setBoxes(boxes.filter((box, i) => i !== deleteIndex ? true : false));
//   }

//   const updateBox = (idx) => {
//     const copyBoxes = [...boxes];
//     copyBoxes[idx].status = !copyBoxes[idx].status;
//     setBoxes(copyBoxes);
//   }

//   return (
//     <div className="App">
//       <h1>task world!</h1>
//       <New createBox={createBox}/>
//       <Boxes boxes={boxes} deleteBox={deleteBox} updateBox={updateBox} />
//     </div>
//   );
// }

// export default App;