import React from 'react';
import { Link } from '@reach/router';
import { useEffect, useState } from 'react';
const Home = (props) => {
  return (
      <div>
        
        <Link to = "/:id">Route Number </Link>
        <Link to = "/">Login </Link>
        <Link to = "/hello/:color1/:color2">Hello Again </Link>
        <div style = {{background_color: {color2}, height: "100px", width: "200px", color: {color1}}}>Hello</div>
      </div>
  );
}
export default Home;