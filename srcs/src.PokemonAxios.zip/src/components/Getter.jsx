import {useState} from 'react';

const Getter = ({pokemon, setPokemon}) => {
    
        fetch("https://pokeapi.co/api/v2/pokemon")
          .then(response => {
            return response.json();
        }).then(response => {
            console.log(response.results);
            setPokemon(response.results);
        }).catch(err=>{
            console.log(err);
        });

}
export default Getter;