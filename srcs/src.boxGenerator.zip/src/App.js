import './App.css';
import React, { useState } from 'react';
// import List from './components/List';
// import Person from './components/Person';
// import Name from './components/Name';
// import Inversion from "./components/Inversion"
// import UserForm from './components/UserForm';
// import DisplayForm from './components/DisplayForm';
// import NewUser from './components/NewUser'
import BoxGenerator from './components/BoxGenerator';
import BoxBox from './components/BoxBox'
// import MessageForm from './components/MessageForm';
// import MessageDisplay from './components/MessageDisplay'


function App() {
  // const [currentMsg, setCurrentMsg] = useState("There are no messages");
  // const youveGotMail = ( newMessage ) => {
  //   setCurrentMsg( newMessage );
  const [currentColor, setCurrentColor]= useState ([]);
  const colorChoice = (newColor) => {
    setCurrentColor( [...currentColor,newColor ])
  }

  

  return (
    <div className="App">
        <>
          <BoxGenerator onNewBox={colorChoice}/>
          {currentColor.map((each,i) => {
            return(
              <BoxBox colorPicked ={each} key = {i} />    
            )
          })}
          
          {/* <MessageForm onNewMessage={ youveGotMail } />
          <MessageDisplay message={ currentMsg } /> */}
        </>
      {/* < UserForm /> */}
      {/* < NewUser /> */}
      {/* <BoxGenerator /> */}
    </div>
  );
}

export default App;
