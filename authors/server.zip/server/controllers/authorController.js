const { response } = require('express');
const { Author } = require('../models/authorModel');



module.exports.createAuthor = (request, response) => {
    const {name} = request.body;
    Author.create({
        name
    })
        .then(product=>response.json(product))
        .catch(err=>response.json(err))
        
}

module.exports.updateAuthor = (request, response) => {
    Author.findOneAndUpdate({_id: request.params.id}, request.body, {new: true})
        .then(updatedAuthor=>response.json(updatedAuthor))
        .catch(err=>response.json(err))

}

module.exports.deleteAuthor = (request, response) => {
    Author.findOneAndDelete({_id: request.params.id})
    .then(deleteConfirmation => response.json(deleteConfirmation))
    .catch(err => response.json("No delete-o", err));

}
