const { response } = require('express');
const {Author}  = require('../models/authorModel');


module.exports.findAuthors = (request, response) => {
    // Author.find()
    //     .then(authors => response.json({oneAuthor: authors}))
    //     .catch(err => response.json(err));
}

module.exports.createAuthor = (request, response) => {
    Author.create(request.body)
        .then(author=>response.json(author))
        .catch(err=>response.json(err))
        
}

module.exports.updateAuthor = (request, response) => {
    Author.findOneAndUpdate({_id: request.params.id}, request.body, {new: true})
        .then(updatedAuthor=>response.json(updatedAuthor))
        .catch(err=>response.json(err))

}

module.exports.deleteAuthor = (request, response) => {
    Author.findOneAndDelete({_id: request.params.id})
    .then(deleteConfirmation => response.json(deleteConfirmation))
    .catch(err => response.json("No delete-o", err));

}

module.exports.seeAuthor = (request, response) => {
    Author.find()
        .then(author=>response.json(author))
        .catch(err=>response.json(err))
        
}
